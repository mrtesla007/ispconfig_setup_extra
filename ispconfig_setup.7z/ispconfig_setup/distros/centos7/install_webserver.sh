#---------------------------------------------------------------------
# Function: InstallWebServer
#    Install and configure Apache2, php + modules
#---------------------------------------------------------------------
InstallWebServer() {

  if [ "$CFG_WEBSERVER" == "apache" ]; then
	CFG_NGINX=n
	CFG_APACHE=y
    echo -n "Installing Web server (Apache)... "
    yum -y install httpd mod_ssl
	echo -e "[${green}DONE${NC}]\n"
	echo -n "Installing PHP and modules... "
	#add webtatic repository
	# referans https://webtatic.com/packages/php71/
	yum install epel-release
	rpm -Uvh https://mirror.webtatic.com/yum/el7/webtatic-release.rpm
	yum -y install mod_php71w php71w-opcache
	yum -y install php71w-bcmath php71w-cli php71w-common php71w-dba php71w-devel php71w-embedded php71w-enchant php71w-gd php71w-imap php71w-interbase php71w-intl php71w-ldap php71w-mbstring php71w-mcrypt php71w-mysql php71w-mysqlnd php71w-odbc php71w-pdo php71w-pdo_dblib php71w-pear php71w-pecl-apcu php71w-pecl-memcached php71w-pecl-mongodb php71w-pecl-redis php71w-pecl-xdebug php71w-pgsql php71w-phpdbg php71w-process php71w-pspell php71w-recode php71w-snmp php71w-soap php71w-tidy php71w-xml php71w-xmlrpc
	echo -n "Installing needed programs for PHP and Apache... "
	yum -y install curl curl-devel perl-libwww-perl  php71w-pecl-imagick libxml2 libxml2-devel mod_fcgid php-cli httpd-devel  php71w-fpm
	echo -e "[${green}DONE${NC}]\n"
	sed -i "s/error_reporting = E_ALL \& ~E_DEPRECATED \& ~E_STRICT/error_reporting = E_ALL \& ~E_NOTICE \& ~E_DEPRECATED/" /etc/php.ini
	sed -i "s/;cgi.fix_pathinfo=1/cgi.fix_pathinfo=1/" /etc/php.ini
	TIME_ZONE=$(echo "$TIME_ZONE" | sed -n 's/ (.*)$//p')
	sed -i "s/;date.timezone =/date.timezone=\"${TIME_ZONE//\//\\/}\"/" /etc/php.ini	
	sed -i '0,/<FilesMatch \\.php$>/ s/<FilesMatch \\.php$>/<Directory \/usr\/share>\n<FilesMatch \\.php$>/' /etc/httpd/conf.d/php.conf
	sed -i '0,/<\/FilesMatch>/ s/<\/FilesMatch>/<\/FilesMatch>\n<\/Directory>/' /etc/httpd/conf.d/php.conf
	
    systemctl start php-fpm.service
    systemctl enable php-fpm.service
    systemctl enable httpd.service
	
	#removed python support for now
	echo -n "Installing mod_python... "
	yum -y install python-devel
	cd /usr/local/src/
	wget -q http://dist.modpython.org/dist/mod_python-3.5.0.tgz
	tar xfz mod_python-3.5.0.tgz
	cd mod_python-3.5.0
	./configure
	make
	sed -e 's/(git describe --always)/(git describe --always 2>\/dev\/null)/g' -e 's/`git describe --always`/`git describe --always 2>\/dev\/null`/g' -i $( find . -type f -name Makefile\* -o -name version.sh )
	make install
	echo 'LoadModule python_module modules/mod_python.so' > /etc/httpd/conf.modules.d/10-python.conf
	echo -e "[${green}DONE${NC}]\n"
	echo "Installing phpMyAdmin... "
	yum -y install phpmyadmin
	echo -e "[${green}DONE${NC}]\n"
   	sed -i "s/Require ip 127.0.0.1/#Require ip 127.0.0.1/" /etc/httpd/conf.d/phpMyAdmin.conf
    	sed -i '0,/Require ip ::1/ s/Require ip ::1/#Require ip ::1\n       Require all granted/' /etc/httpd/conf.d/phpMyAdmin.conf
	sed -i "s/'cookie'/'http'/" /etc/phpMyAdmin/config.inc.php
    systemctl enable  httpd.service
    systemctl restart  httpd.service
	# echo -e "${green}done! ${NC}\n"
elif [ "$CFG_WEBSERVER" == "nginx" ]; then
	CFG_NGINX=y
	CFG_APACHE=n
    echo -n "Installing Web server (nginx)... "
    yum -y install nginx
	echo -e "[${green}DONE${NC}]\n"
	echo -n "Installing PHP and modules... "
	yum -y install mod_ssl php php-mysql php-mbstring
	yum -y install php-devel php-gd php-imap php-ldap php-mysql php-odbc php-pear php-xml php-xmlrpc php-pecl-apc php-mbstring php-mcrypt php-mssql php-snmp php-soap php-tidy
    echo -n "Installing needed programs for PHP and Apache... "
	yum -y install curl curl-devel perl-libwww-perl ImageMagick libxml2 libxml2-devel mod_fcgid php-cli httpd-devel php-fpm wget
	echo -e "[${green}DONE${NC}]\n"
	sed -i "s/error_reporting = E_ALL \& ~E_DEPRECATED \& ~E_STRICT/error_reporting = E_ALL \& ~E_NOTICE \& ~E_DEPRECATED/" /etc/php.ini
	sed -i "s/;cgi.fix_pathinfo=1/cgi.fix_pathinfo=1/" /etc/php.ini
	TIME_ZONE=$(echo "$TIME_ZONE" | sed -n 's/ (.*)$//p')
	sed -i "s/;date.timezone =/date.timezone=\"${TIME_ZONE//\//\\/}\"/" /etc/php.ini
   systemctl start php-fpm.service
   systemctl enable php-fpm.service
   systemctl enable nginx.service
 fi

  # echo -e "${green}done! ${NC}\n"

  echo -n "Installing Let's Encrypt (Certbot)... "
  yum -y install certbot

  echo -e "[${green}DONE${NC}]\n"
}
